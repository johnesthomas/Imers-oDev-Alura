var valorEmDolar = parseFloat(prompt("Qual o valor em dolar que você quer converter ?"))

var valorEmReal = (valorEmDolar * 5.5).toFixed(2)

alert("Valor em real: " + valorEmReal)

console.log("Valor em real: " + valorEmReal)